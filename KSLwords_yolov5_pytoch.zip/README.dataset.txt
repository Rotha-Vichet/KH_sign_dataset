# KH Sign Language Detection > 2025-02-19 11:00am
https://universe.roboflow.com/tranings-dataset/kh-sign-language-detection

Provided by a Roboflow user
License: CC BY 4.0

