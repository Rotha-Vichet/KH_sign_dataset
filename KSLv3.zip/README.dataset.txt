# KH Sign Language Detection > 2025-02-03 6:59pm
https://universe.roboflow.com/tranings-dataset/kh-sign-language-detection

Provided by a Roboflow user
License: CC BY 4.0

